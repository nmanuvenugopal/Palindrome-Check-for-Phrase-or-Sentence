sent_phrase = input("Enter the phrase: ")

input_list = []
for str in sent_phrase:
    if str.isalnum():
        input_list.append(str.lower())

print(f"The input string without special characters: {''.join(input_list).lower()}")

rev_input_list = input_list[::-1]
print(f"The reverse phrase is : {''.join(rev_input_list)}")

if input_list == rev_input_list:
    print("The phrase is Palindrome")
else:
    print("The phrase is not Palindrome")


# Test Input - "A man, a plan, a canal: Panama" - Palindrome
# Test Input - " Amal is a good boy" - Not Palindrome